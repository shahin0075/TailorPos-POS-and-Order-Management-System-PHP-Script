<?php

namespace App\Http\Livewire\Admin\Invoice;

use Livewire\Component;

class RTLInvoice extends Component
{
    //render the page
    public function render()
    {
        return view('livewire.admin.invoice.r-t-l-invoice');
    }
}