<?php

namespace App\Http\Livewire\Admin\Reports;

use Livewire\Component;

class TaxReport extends Component
{
    // render the page
    public function render()
    {
        return view('livewire.admin.reports.tax-report');
    }
}