<?php

namespace App\Http\Livewire\Components;

use Livewire\Component;

class SuperAdminSidebar extends Component
{
    // render the page
    public function render()
    {
        return view('livewire..components.super-admin-sidebar');
    }
}