function myFunction() {
    "use strict";
    window.print();
}