<?php

return [
    'thermal_title' => 'Simplified Tax Invoice',
    'item' => 'Item',
    'advance' => 'Advance',
    'no' => 'NO',
    'received_from' => "Received from Mr./M/s",
    'amount_in_words' => 'Amount in words',
    'currency_words' => 'INR only',
    'being_for' => 'Being for',
    'receivers_sign' => "Receiver's Sign",
    'signature' => "Signature",
];
