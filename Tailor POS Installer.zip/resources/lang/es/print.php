<?php

return [
    'thermal_title' => "Factura fiscal simplificada",
    'item' => "Tema",
    'advance' => "Avance",
    'no' => "NO",
    'received_from' => "Recibido por el Sr./M/s",
    'amount_in_words' => "Cantidad en palabras",
    'currency_words' => "INR sólo",
    'being_for' => "Ser para",
    'receivers_sign' => "Signo del receptor",
    'signature' => "Firma",
];
