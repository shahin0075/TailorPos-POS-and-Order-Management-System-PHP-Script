<?php

return [
    'thermal_title' => "Facture fiscale simplifiée",
    'item' => "Point",
    'advance' => "Avance",
    'no' => "NO",
    'received_from' => "Reçu de M./M/s",
    'amount_in_words' => "Montant en mots",
    'currency_words' => "INR only",
    'being_for' => "Être pour",
    'receivers_sign' => "Signe du receveur",
    'signature' => "Signature",
];