<?php

return [
    'thermal_title' => "सरलीकृत कर चालान",
    'item' => "आइटम",
    'advance' => "अग्रिम",
    'no' => "नहीं",
    'received_from' => "Mr./M/s से प्राप्त",
    'amount_in_words' => "शब्दों में राशि",
    'currency_words' => "केवल INR",
    'being_for' => "होना",
    'receivers_sign' => "रिसीवर का संकेत",
    'signature' => "हस्ताक्षर",
];
