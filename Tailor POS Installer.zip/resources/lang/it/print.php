<?php

return [
    'thermal_title' => "Fatturazione fiscale semplificata",
    'item' => "Articolo",
    'advance' => "Avanti",
    'no' => "NO",
    'received_from' => "Ricevuto dal signor/M/s",
    'amount_in_words' => "Importo delle parole",
    'currency_words' => "INR solo",
    'being_for' => "Essere per",
    'receivers_sign' => "Segno del ricevitore",
    'signature' => "Firma",
];