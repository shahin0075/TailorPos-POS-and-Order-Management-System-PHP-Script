<?php

return [
    'thermal_title' => "Упрощенный налоговый счет",
    'item' => "Пункт",
    'advance' => "Аванс",
    'no' => "НЕТ",
    'received_from' => "Получено от г-на/М/с",
    'amount_in_words' => "Количество слов",
    'currency_words' => "INR only",
    'being_for' => "Быть для",
    'receivers_sign' => "Знак получателя",
    'signature' => "Подписание",
];