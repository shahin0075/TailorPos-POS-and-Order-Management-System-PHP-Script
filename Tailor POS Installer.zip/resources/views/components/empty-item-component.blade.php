<div>
   <div class="card my-custom-scrollbar-bill border-0 ">
    <div class="card-body d-flex justify-content-center align-items-center">
        <h4>{{$title}}</h4>
    </div>
   </div>
</div>