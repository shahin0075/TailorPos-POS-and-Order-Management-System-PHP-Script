<div class="flex w-full items-center  justify-center shrink-0">
   
</div>